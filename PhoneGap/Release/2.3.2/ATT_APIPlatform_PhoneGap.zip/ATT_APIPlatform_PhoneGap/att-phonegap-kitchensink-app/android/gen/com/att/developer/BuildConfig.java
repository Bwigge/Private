/** Automatically generated file. DO NOT MODIFY */
package com.att.developer;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}